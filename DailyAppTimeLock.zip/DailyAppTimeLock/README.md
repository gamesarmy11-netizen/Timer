# 🛡️ Daily App Time Lock — Android App

**Full-featured Android screen time enforcement app with strict blocking logic.**

---

## 📁 Project Structure

```
DailyAppTimeLock/
├── app/
│   ├── src/main/
│   │   ├── java/com/dailyapplock/
│   │   │   ├── DailyAppLockApplication.kt          # App class, DI, notification channels
│   │   │   ├── data/
│   │   │   │   ├── db/
│   │   │   │   │   ├── AppDatabase.kt              # Room database singleton
│   │   │   │   │   └── AppLimitDao.kt              # All DB queries
│   │   │   │   ├── models/
│   │   │   │   │   ├── AppLimit.kt                 # DB entity (limits + usage)
│   │   │   │   │   └── InstalledApp.kt             # Transient model for UI
│   │   │   │   └── repository/
│   │   │   │       └── AppLimitRepository.kt       # Single source of truth
│   │   │   ├── service/
│   │   │   │   ├── AppMonitorService.kt            # ⭐ Core foreground service (400ms poll)
│   │   │   │   ├── BlockAccessibilityService.kt    # ⭐ Accessibility blocking layer
│   │   │   │   └── DailyResetWorker.kt             # WorkManager midnight reset
│   │   │   ├── receiver/
│   │   │   │   ├── BootReceiver.kt                 # Restart after reboot
│   │   │   │   ├── MidnightResetReceiver.kt        # Fallback reset
│   │   │   │   └── PackageReceiver.kt              # Handle app uninstalls
│   │   │   ├── ui/
│   │   │   │   ├── activities/
│   │   │   │   │   ├── SplashActivity.kt           # Entry point + routing
│   │   │   │   │   ├── PermissionOnboardingActivity.kt  # 4-step permission setup
│   │   │   │   │   ├── PinActivity.kt              # PIN setup + verification
│   │   │   │   │   ├── MainActivity.kt             # Dashboard
│   │   │   │   │   ├── AppSelectionActivity.kt     # Browse installed apps
│   │   │   │   │   ├── SetLimitActivity.kt         # Configure per-app limit
│   │   │   │   │   └── LockScreenActivity.kt       # ⭐ Full-screen block overlay
│   │   │   │   ├── adapters/
│   │   │   │   │   ├── AppLimitAdapter.kt          # Dashboard RecyclerView
│   │   │   │   │   └── InstalledAppAdapter.kt      # App selection RecyclerView
│   │   │   │   └── viewmodels/
│   │   │   │       ├── DashboardViewModel.kt
│   │   │   │       ├── AppSelectionViewModel.kt
│   │   │   │       └── SetLimitViewModel.kt
│   │   │   └── utils/
│   │   │       ├── PermissionHelper.kt             # Permission checks + intents
│   │   │       ├── PreferenceManager.kt            # SharedPreferences wrapper
│   │   │       ├── PinHasher.kt                   # SHA-256 PIN hashing
│   │   │       └── TimeUtils.kt                    # Time formatting utilities
│   │   └── res/
│   │       ├── layout/                             # All XML layouts
│   │       ├── drawable/                           # Icons + shapes
│   │       ├── values/                             # Colors, strings, themes, dimens
│   │       ├── menu/                               # Menu XML
│   │       └── xml/                               # Accessibility config, backup rules
│   └── AndroidManifest.xml
├── build.gradle
├── settings.gradle
└── README.md
```

---

## 🚀 How to Build in Android Studio

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17+
- Android SDK 34
- Kotlin 1.9.0+

### Steps

1. **Open Project**
   - Open Android Studio → File → Open → Select `DailyAppTimeLock/` folder

2. **Sync Gradle**
   - Click "Sync Now" in the notification bar (or File → Sync Project with Gradle Files)

3. **Connect Device**
   - Enable Developer Options + USB Debugging on your Android phone
   - Connect via USB

4. **Run**
   - Click ▶ Run or Shift+F10

5. **Build APK**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

---

## ⚙️ Required Permissions (Grant in Order)

| Permission | How to Grant | Required? |
|---|---|---|
| **Usage Access** | Settings → Special App Access → Usage Access | ✅ Yes |
| **Draw Over Apps** | Settings → Special App Access → Display over other apps | ✅ Yes |
| **Accessibility Service** | Settings → Accessibility → Daily App Time Lock Blocker | ⭐ Strongly Recommended |
| **Battery Optimization** | Settings → Battery → Ignore Optimizations | 📱 Recommended |

The app's onboarding flow guides you through all of these step by step.

---

## 🔒 How Blocking Works

### Dual-Layer Architecture

```
Layer 1: AppMonitorService (Foreground Service)
  └─ Polls getForegroundPackage() every 400ms via UsageStatsManager
  └─ Tracks per-session usage time
  └─ Flushes seconds to Room DB on app switch
  └─ Triggers LockScreenActivity when limit reached

Layer 2: BlockAccessibilityService
  └─ Listens to TYPE_WINDOW_STATE_CHANGED events
  └─ Instantly blocks via performGlobalAction(GLOBAL_ACTION_HOME)
  └─ Shows LockScreenActivity for any blocked package
  └─ Covers: notifications, recent apps, deep links, shortcuts
```

### Example Flow (YouTube = 1 hour limit)

```
09:00 → YouTube opened     → Session timer starts
09:20 → YouTube closed     → 20m flushed to DB  [used: 20m, remaining: 40m]
14:00 → YouTube reopened   → Session timer starts
14:25 → YouTube closed     → 25m flushed to DB  [used: 45m, remaining: 15m]
20:00 → YouTube reopened   → Session timer starts
20:10 → Warning sent       → "5 minutes remaining today"
20:15 → Limit reached!     → LockScreenActivity shown
         ┌─────────────────────────────────────┐
         │  🔒 YouTube                          │
         │  You've reached your daily limit     │
         │  Resets in 03:45:00                 │
         │  [← Go Home]  [Open Dashboard]      │
         └─────────────────────────────────────┘
20:15 → User tries reopening YouTube via notification
         → AccessibilityService detects it
         → performGlobalAction(HOME) immediately
         → LockScreenActivity re-shown
00:00 → DailyResetWorker fires → All usage reset to 0
20:16+→ YouTube unblocked ✅
```

### Auto-Reset (Midnight)
- WorkManager schedules `DailyResetWorker` to run exactly at next 00:00:00 local time
- After each reset, re-schedules for next midnight
- BootReceiver re-schedules after device reboot
- AlarmManager fallback also available

---

## 🔐 Security Features

- **PIN Protection**: 4-digit PIN with SHA-256+Salt hashing, stored in `EncryptedSharedPreferences`
- **Tamper Detection**: If Usage Access is revoked mid-session, a high-priority alert notification is shown
- **Persist After Reboot**: `BootReceiver` restarts `AppMonitorService` and re-schedules WorkManager on `BOOT_COMPLETED`
- **Lock Screen**: Cannot be dismissed by Back button; only "Go Home" button works
- **All re-open vectors blocked**: Accessibility covers notifications, recent apps, intents, deep links

---

## 📱 UI Screens

| Screen | Purpose |
|---|---|
| Splash | App entry, routes to onboarding/PIN/dashboard |
| Permission Onboarding | 4-step guided permission setup with status indicators |
| PIN Setup/Verify | 4-digit secure PIN entry with numpad |
| Dashboard (MainActivity) | Live usage stats, blocked apps, reset countdown |
| App Selection | Searchable list of all installed apps |
| Set Limit | Presets (15m/30m/1h/2h/3h) + custom hours:minutes picker |
| Lock Screen | Full-screen block overlay with countdown to midnight reset |

---

## 🎨 Design System

- **Theme**: Dark AMOLED — `#0D0D0F` background
- **Primary accent**: Purple `#7C4DFF`
- **Secondary accent**: Cyan `#00E5FF`
- **Blocked state**: Red `#FF3D3D`
- **Safe state**: Green `#00E676`
- **Warning state**: Yellow `#FFD600`

---

## 🛠️ Tech Stack

| Component | Library/API |
|---|---|
| Language | Kotlin |
| Architecture | MVVM + Repository |
| Database | Room 2.6.1 |
| Background tasks | WorkManager 2.9.0 |
| Foreground monitoring | Custom Service + UsageStatsManager |
| App blocking | AccessibilityService |
| Async | Kotlin Coroutines + Flow |
| UI | Material Design 3 + ViewBinding |
| Security | EncryptedSharedPreferences + SHA-256 |

---

## 📝 Notes for Production

1. **Auto-start on OEM ROMs** (Xiaomi, OPPO, Huawei): User must manually enable auto-start in device's own battery settings. The app includes common intent filters for common OEMs.

2. **UsageStatsManager accuracy**: Android batches usage events. Our 400ms poll + 3-second query window minimises stale data risk.

3. **Strict Mode**: Remove `fallbackToDestructiveMigration()` and add proper `Migration` objects before production.

4. **Testing Blocking**: Use ADB to simulate time:
   ```bash
   adb shell date -s "2024-01-15 23:59:50"
   ```

---

*Built with ❤️ — Daily App Time Lock v1.0.0*
