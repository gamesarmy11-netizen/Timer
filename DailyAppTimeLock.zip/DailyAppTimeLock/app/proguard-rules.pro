# Add project specific ProGuard rules here.

# Keep Room entities
-keep class com.dailyapplock.data.models.** { *; }
-keep class com.dailyapplock.data.db.** { *; }

# Keep WorkManager workers
-keep class com.dailyapplock.service.DailyResetWorker { *; }

# Keep Accessibility Service
-keep class com.dailyapplock.service.BlockAccessibilityService { *; }

# Keep Receivers
-keep class com.dailyapplock.receiver.** { *; }

# Keep Application class
-keep class com.dailyapplock.DailyAppLockApplication { *; }

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Glide
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { <init>(...); }
-keep public enum com.bumptech.glide.load.ImageHeaderParser$** {
  **[] $VALUES; public *; }
