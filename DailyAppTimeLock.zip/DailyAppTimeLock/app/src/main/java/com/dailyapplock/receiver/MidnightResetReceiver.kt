package com.dailyapplock.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.dailyapplock.DailyAppLockApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * MidnightResetReceiver — fallback alarm-based reset.
 * WorkManager handles the primary reset; this is a safety net.
 */
class MidnightResetReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "Midnight reset triggered")
        val app = context.applicationContext as DailyAppLockApplication
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            app.repository.resetAllForToday()
            Log.d(TAG, "Midnight reset complete")
        }
    }

    companion object {
        private const val TAG = "MidnightResetReceiver"
    }
}
