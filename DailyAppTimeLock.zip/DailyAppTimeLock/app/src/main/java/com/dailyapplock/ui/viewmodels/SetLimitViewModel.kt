package com.dailyapplock.ui.viewmodels

import android.app.Application
import androidx.lifecycle.*
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.data.models.AppLimit
import com.dailyapplock.data.repository.AppLimitRepository
import com.dailyapplock.utils.TimeUtils
import kotlinx.coroutines.launch

/**
 * ViewModel for the Set Limit screen.
 * Handles saving/updating a time limit for a specific app.
 */
class SetLimitViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppLimitRepository =
        (application as DailyAppLockApplication).repository

    private val _saved = MutableLiveData(false)
    val saved: LiveData<Boolean> = _saved

    private val _existingLimit = MutableLiveData<AppLimit?>()
    val existingLimit: LiveData<AppLimit?> = _existingLimit

    fun loadExistingLimit(packageName: String) {
        viewModelScope.launch {
            _existingLimit.value = repository.getAppLimit(packageName)
        }
    }

    fun saveLimit(packageName: String, appName: String, limitMinutes: Int) {
        if (limitMinutes <= 0) return

        viewModelScope.launch {
            val existing = repository.getAppLimit(packageName)
            val today = TimeUtils.todayString()

            val limit = AppLimit(
                packageName    = packageName,
                appName        = appName,
                limitMinutes   = limitMinutes,
                usedSeconds    = existing?.usedSeconds ?: 0L,
                isBlocked      = existing?.isBlocked ?: false,
                isEnabled      = true,
                lastResetDate  = existing?.lastResetDate ?: today,
                warningSent    = existing?.warningSent ?: false
            )
            repository.saveAppLimit(limit)
            _saved.postValue(true)
        }
    }
}
