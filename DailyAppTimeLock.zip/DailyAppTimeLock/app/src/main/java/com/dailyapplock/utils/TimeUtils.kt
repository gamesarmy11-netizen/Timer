package com.dailyapplock.utils

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Utility functions for time formatting and calculations.
 */
object TimeUtils {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    /** Today's date string in "yyyy-MM-dd" format. */
    fun todayString(): String = dateFormat.format(Date())

    /**
     * Formats seconds into a human-readable string.
     * Examples: "1h 23m", "45m 10s", "30s"
     */
    fun formatSeconds(totalSeconds: Long): String {
        val hours   = TimeUnit.SECONDS.toHours(totalSeconds)
        val minutes = TimeUnit.SECONDS.toMinutes(totalSeconds) % 60
        val seconds = totalSeconds % 60

        return when {
            hours > 0   -> "${hours}h ${minutes}m"
            minutes > 0 -> "${minutes}m ${seconds}s"
            else        -> "${seconds}s"
        }
    }

    /**
     * Formats minutes into a concise string for the limit badge.
     * Examples: "1h", "30m", "1h 30m"
     */
    fun formatMinutes(totalMinutes: Int): String {
        val hours   = totalMinutes / 60
        val minutes = totalMinutes % 60
        return when {
            hours > 0 && minutes > 0 -> "${hours}h ${minutes}m"
            hours > 0               -> "${hours}h"
            else                    -> "${minutes}m"
        }
    }

    /**
     * Milliseconds until the next midnight (12:00:00 AM local time).
     */
    fun millisUntilMidnight(): Long {
        val now = Calendar.getInstance()
        val midnight = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return midnight.timeInMillis - now.timeInMillis
    }

    /**
     * Formats a duration (in millis) as a countdown "HH:MM:SS".
     */
    fun formatCountdown(millis: Long): String {
        if (millis <= 0) return "00:00:00"
        val hours   = TimeUnit.MILLISECONDS.toHours(millis)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    /** Returns true if the given date string is today. */
    fun isToday(dateString: String): Boolean {
        return dateString == todayString()
    }
}
