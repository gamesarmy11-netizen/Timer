package com.dailyapplock.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Centralised preference manager.
 * Uses EncryptedSharedPreferences for sensitive data (PIN hash).
 */
class PreferenceManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    // Encrypted prefs for PIN storage
    private val securePrefs: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                SECURE_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Fallback if encryption is unavailable
            context.getSharedPreferences(SECURE_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    // ─── PIN ────────────────────────────────────────────────────────────────

    var pinHash: String
        get() = securePrefs.getString(KEY_PIN_HASH, "") ?: ""
        set(value) = securePrefs.edit().putString(KEY_PIN_HASH, value).apply()

    var isPinEnabled: Boolean
        get() = prefs.getBoolean(KEY_PIN_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_PIN_ENABLED, value).apply()

    // ─── Onboarding ─────────────────────────────────────────────────────────

    var isOnboardingComplete: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING_DONE, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING_DONE, value).apply()

    // ─── Service state ───────────────────────────────────────────────────────

    var isMonitoringActive: Boolean
        get() = prefs.getBoolean(KEY_MONITORING_ACTIVE, true)
        set(value) = prefs.edit().putBoolean(KEY_MONITORING_ACTIVE, value).apply()

    // ─── Last reset date ─────────────────────────────────────────────────────

    var lastResetDate: String
        get() = prefs.getString(KEY_LAST_RESET, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_RESET, value).apply()

    // ─── Warning threshold ───────────────────────────────────────────────────

    var warningThresholdMinutes: Int
        get() = prefs.getInt(KEY_WARNING_THRESHOLD, 5)
        set(value) = prefs.edit().putInt(KEY_WARNING_THRESHOLD, value).apply()

    // ─── Tamper detection ────────────────────────────────────────────────────

    var lastKnownPermissionState: Boolean
        get() = prefs.getBoolean(KEY_LAST_PERM_STATE, false)
        set(value) = prefs.edit().putBoolean(KEY_LAST_PERM_STATE, value).apply()

    companion object {
        private const val PREFS_NAME        = "daily_app_lock_prefs"
        private const val SECURE_PREFS_NAME = "daily_app_lock_secure"

        private const val KEY_PIN_HASH          = "pin_hash"
        private const val KEY_PIN_ENABLED       = "pin_enabled"
        private const val KEY_ONBOARDING_DONE   = "onboarding_done"
        private const val KEY_MONITORING_ACTIVE = "monitoring_active"
        private const val KEY_LAST_RESET        = "last_reset_date"
        private const val KEY_WARNING_THRESHOLD = "warning_threshold"
        private const val KEY_LAST_PERM_STATE   = "last_perm_state"
    }
}
