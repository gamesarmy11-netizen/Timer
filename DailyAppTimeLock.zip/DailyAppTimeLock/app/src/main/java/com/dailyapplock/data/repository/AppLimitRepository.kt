package com.dailyapplock.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.lifecycle.LiveData
import com.dailyapplock.data.db.AppDatabase
import com.dailyapplock.data.models.AppLimit
import com.dailyapplock.data.models.InstalledApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Repository — mediates between Room database and the UI/ViewModel layer.
 * All suspend functions run off the main thread.
 */
class AppLimitRepository(private val db: AppDatabase) {

    private val dao = db.appLimitDao()

    // ─── LiveData / Flow observers ───────────────────────────────────────────

    val allLimitsLive: LiveData<List<AppLimit>> = dao.getAllLimitsLive()
    val blockedAppsLive: LiveData<List<AppLimit>> = dao.getBlockedAppsLive()
    val blockedCountLive: LiveData<Int> = dao.getBlockedCountLive()
    val allLimitsFlow: Flow<List<AppLimit>> = dao.getAllLimitsFlow()

    // ─── CRUD ────────────────────────────────────────────────────────────────

    suspend fun saveAppLimit(appLimit: AppLimit) = withContext(Dispatchers.IO) {
        dao.insertOrUpdate(appLimit)
    }

    suspend fun deleteAppLimit(packageName: String) = withContext(Dispatchers.IO) {
        dao.deleteByPackage(packageName)
    }

    suspend fun getAppLimit(packageName: String): AppLimit? = withContext(Dispatchers.IO) {
        dao.getByPackageName(packageName)
    }

    fun getAppLimitSync(packageName: String): AppLimit? = dao.getByPackageSync(packageName)

    fun getAllLimitsSync(): List<AppLimit> = dao.getAllLimitsSync()

    fun getBlockedAppsSync(): List<AppLimit> = dao.getBlockedAppsSync()

    // ─── Usage tracking ──────────────────────────────────────────────────────

    suspend fun addUsedSeconds(packageName: String, seconds: Long) = withContext(Dispatchers.IO) {
        dao.addUsedSeconds(packageName, seconds)
    }

    suspend fun markBlocked(packageName: String) = withContext(Dispatchers.IO) {
        dao.markBlocked(packageName)
    }

    suspend fun markWarningSent(packageName: String) = withContext(Dispatchers.IO) {
        dao.markWarningSent(packageName)
    }

    // ─── Reset ───────────────────────────────────────────────────────────────

    suspend fun resetAllForToday() = withContext(Dispatchers.IO) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        dao.resetAllForDay(today)
    }

    suspend fun resetAppForToday(packageName: String) = withContext(Dispatchers.IO) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        dao.resetAppForDay(packageName, today)
    }

    // ─── Package Manager helpers ─────────────────────────────────────────────

    /**
     * Returns a list of all non-system user apps installed on the device.
     * Excludes our own package to prevent self-locking.
     */
    suspend fun getInstalledApps(context: Context): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val existingLimits = getAllLimitsSync().associateBy { it.packageName }

        pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { appInfo ->
                // Only user-installed apps; exclude our own app
                (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                        appInfo.packageName != context.packageName
            }
            .map { appInfo ->
                val existingLimit = existingLimits[appInfo.packageName]
                InstalledApp(
                    packageName = appInfo.packageName,
                    appName = pm.getApplicationLabel(appInfo).toString(),
                    icon = try { pm.getApplicationIcon(appInfo.packageName) } catch (e: Exception) { null },
                    isSystemApp = false,
                    hasLimit = existingLimit != null,
                    limitMinutes = existingLimit?.limitMinutes ?: 0
                )
            }
            .sortedWith(compareByDescending<InstalledApp> { it.hasLimit }.thenBy { it.appName })
    }
}
