package com.dailyapplock.ui.viewmodels

import android.app.Application
import androidx.lifecycle.*
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.data.models.AppLimit
import com.dailyapplock.data.repository.AppLimitRepository
import com.dailyapplock.utils.TimeUtils
import kotlinx.coroutines.launch

/**
 * ViewModel for the Dashboard screen.
 * Exposes LiveData for all monitored apps, blocked count, and reset countdown.
 */
class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppLimitRepository =
        (application as DailyAppLockApplication).repository

    // All enabled app limits for the dashboard list
    val allLimits: LiveData<List<AppLimit>> = repository.allLimitsLive

    // Count of currently blocked apps
    val blockedCount: LiveData<Int> = repository.blockedCountLive

    // Blocked apps list
    val blockedApps: LiveData<List<AppLimit>> = repository.blockedAppsLive

    // Countdown to midnight (refreshed every second via ticker)
    private val _countdownMillis = MutableLiveData<Long>()
    val countdownFormatted: LiveData<String> = _countdownMillis.map { millis ->
        TimeUtils.formatCountdown(millis)
    }

    // Error / info messages
    private val _message = MutableLiveData<String?>()
    val message: LiveData<String?> = _message

    init {
        startCountdownTicker()
    }

    private fun startCountdownTicker() {
        viewModelScope.launch {
            while (true) {
                _countdownMillis.postValue(TimeUtils.millisUntilMidnight())
                kotlinx.coroutines.delay(1_000)
            }
        }
    }

    fun deleteAppLimit(appLimit: AppLimit) {
        viewModelScope.launch {
            repository.deleteAppLimit(appLimit.packageName)
            _message.postValue("Removed ${appLimit.appName}")
        }
    }

    fun resetAppManually(appLimit: AppLimit) {
        viewModelScope.launch {
            repository.resetAppForToday(appLimit.packageName)
            _message.postValue("Reset ${appLimit.appName} for today")
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
