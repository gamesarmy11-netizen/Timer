package com.dailyapplock.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.data.repository.AppLimitRepository
import com.dailyapplock.ui.activities.LockScreenActivity
import kotlinx.coroutines.*

/**
 * BlockAccessibilityService — secondary blocking layer.
 *
 * Listens for window state change events (app switching, recent apps, notifications)
 * and immediately blocks any attempt to open a time-limited app that has been blocked.
 *
 * This service works alongside AppMonitorService:
 *  - AppMonitorService → accurate usage tracking via UsageStatsManager
 *  - BlockAccessibilityService → instant reaction to window events (no polling delay)
 *
 * The combination closes the gap where a user might:
 *  1. Tap a notification deep link
 *  2. Switch via recent apps
 *  3. Open via launcher
 *  4. Use a shortcut/widget
 */
class BlockAccessibilityService : AccessibilityService() {

    private lateinit var repository: AppLimitRepository
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // In-memory blocked package set (updated every 5 seconds)
    private val blockedPackages = mutableSetOf<String>()
    private val refreshHandler = android.os.Handler(android.os.Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        repository = (application as DailyAppLockApplication).repository
        scheduleBlockedRefresh()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Configure what events to listen to
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        Log.d(TAG, "BlockAccessibilityService connected")
        refreshBlockedPackages()
    }

    /**
     * Called every time a window state changes (app switch, dialog, notification panel, etc.)
     */
    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return

        // Ignore our own package to avoid blocking the lock screen itself
        if (packageName == this.packageName) return
        // Ignore system UI (status bar, launcher, recents)
        if (isSystemPackage(packageName)) return

        if (blockedPackages.contains(packageName)) {
            Log.d(TAG, "Accessibility blocking $packageName")
            performGlobalAction(GLOBAL_ACTION_HOME)   // send user Home immediately
            showLockOverlay(packageName)
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "BlockAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        refreshHandler.removeCallbacksAndMessages(null)
        serviceScope.cancel()
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private fun showLockOverlay(packageName: String) {
        serviceScope.launch(Dispatchers.IO) {
            val limit = repository.getAppLimit(packageName) ?: return@launch
            if (!limit.isBlocked) return@launch

            val intent = LockScreenActivity.newIntent(this@BlockAccessibilityService, packageName, limit.appName)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                          Intent.FLAG_ACTIVITY_CLEAR_TOP or
                          Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
        }
    }

    /**
     * Returns true for well-known system / launcher packages that should never be blocked.
     */
    private fun isSystemPackage(packageName: String): Boolean {
        val systemPrefixes = listOf(
            "com.android.",
            "android.",
            "com.google.android.apps.nexuslauncher",
            "com.google.android.launcher",
            "com.sec.android.app.launcher",    // Samsung
            "com.miui.home",                   // Xiaomi
            "com.huawei.android.launcher",     // Huawei
            "com.coloros.launcher",            // OPPO
            "com.vivo.launcher",               // Vivo
            "com.oneplus.launcher",            // OnePlus
            "com.realme.launcher"              // Realme
        )
        return systemPrefixes.any { packageName.startsWith(it) } ||
               packageName == this.packageName
    }

    private fun refreshBlockedPackages() {
        serviceScope.launch {
            val blocked = repository.getBlockedAppsSync()
            synchronized(blockedPackages) {
                blockedPackages.clear()
                blockedPackages.addAll(blocked.map { it.packageName })
            }
        }
    }

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshBlockedPackages()
            refreshHandler.postDelayed(this, REFRESH_INTERVAL_MS)
        }
    }

    private fun scheduleBlockedRefresh() {
        refreshHandler.post(refreshRunnable)
    }

    companion object {
        private const val TAG = "BlockA11yService"
        private const val REFRESH_INTERVAL_MS = 5_000L  // refresh blocked list every 5s
    }
}
