package com.dailyapplock.service

import android.content.Context
import android.util.Log
import androidx.work.*
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.utils.TimeUtils
import java.util.concurrent.TimeUnit

/**
 * DailyResetWorker — scheduled via WorkManager to run at midnight each day.
 *
 * Resets all app usage counters and unblocks apps.
 * Uses an initial delay calculated from "now until next midnight".
 * After each run, re-schedules itself for the following midnight.
 */
class DailyResetWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            Log.d(TAG, "DailyResetWorker running — resetting all app limits")

            val app = applicationContext as DailyAppLockApplication
            app.repository.resetAllForToday()

            Log.d(TAG, "Daily reset complete at ${TimeUtils.todayString()}")

            // Schedule the next reset for tomorrow midnight
            scheduleNextReset(applicationContext)

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "DailyResetWorker failed: ${e.message}")
            Result.retry()
        }
    }

    companion object {
        private const val TAG = "DailyResetWorker"
        private const val WORK_TAG = "daily_reset"

        /**
         * Schedules the DailyResetWorker to run at next midnight.
         * Call this on first launch and after each reset run.
         */
        fun scheduleMidnightReset(context: Context) {
            val delayMs = TimeUtils.millisUntilMidnight()
            Log.d(TAG, "Scheduling reset in ${delayMs / 60_000} minutes")

            val constraints = Constraints.Builder()
                .setRequiresBatteryNotLow(false)   // run even on low battery
                .build()

            val request = OneTimeWorkRequestBuilder<DailyResetWorker>()
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .setConstraints(constraints)
                .addTag(WORK_TAG)
                .setBackoffCriteria(
                    BackoffPolicy.LINEAR,
                    WorkRequest.MIN_BACKOFF_MILLIS,
                    TimeUnit.MILLISECONDS
                )
                .build()

            WorkManager.getInstance(context)
                .enqueueUniqueWork(WORK_TAG, ExistingWorkPolicy.REPLACE, request)
        }

        /** Re-schedule for tomorrow after each reset. */
        private fun scheduleNextReset(context: Context) {
            scheduleMidnightReset(context)
        }

        /** Cancel any pending reset (use on uninstall/disable). */
        fun cancelReset(context: Context) {
            WorkManager.getInstance(context).cancelAllWorkByTag(WORK_TAG)
        }
    }
}
