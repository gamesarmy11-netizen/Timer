package com.dailyapplock.ui.viewmodels

import android.app.Application
import androidx.lifecycle.*
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.data.models.InstalledApp
import com.dailyapplock.data.repository.AppLimitRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ViewModel for the App Selection screen.
 * Loads installed apps and provides search/filter support.
 */
class AppSelectionViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppLimitRepository =
        (application as DailyAppLockApplication).repository

    private val _allApps = MutableLiveData<List<InstalledApp>>()
    private val _filteredApps = MutableLiveData<List<InstalledApp>>()
    val filteredApps: LiveData<List<InstalledApp>> = _filteredApps

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private var searchQuery = ""

    fun loadInstalledApps() {
        viewModelScope.launch {
            _isLoading.value = true
            val apps = withContext(Dispatchers.IO) {
                repository.getInstalledApps(getApplication())
            }
            _allApps.value = apps
            applyFilter()
            _isLoading.value = false
        }
    }

    fun search(query: String) {
        searchQuery = query.trim().lowercase()
        applyFilter()
    }

    private fun applyFilter() {
        val all = _allApps.value ?: return
        _filteredApps.value = if (searchQuery.isEmpty()) all
        else all.filter { it.appName.lowercase().contains(searchQuery) }
    }
}
