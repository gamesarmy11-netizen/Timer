package com.dailyapplock.ui.activities

import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.dailyapplock.databinding.ActivitySetLimitBinding
import com.dailyapplock.ui.viewmodels.SetLimitViewModel
import com.google.android.material.chip.Chip

/**
 * SetLimitActivity — configure a daily time limit for a selected app.
 *
 * Preset options: 15m, 30m, 1h, 2h, 3h, Custom (number picker)
 */
class SetLimitActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySetLimitBinding
    private val viewModel: SetLimitViewModel by viewModels()

    private val packageName: String by lazy { intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: "" }
    private val appName: String     by lazy { intent.getStringExtra(EXTRA_APP_NAME) ?: "" }

    // Currently selected limit in minutes
    private var selectedMinutes = 0

    // Preset options (minutes)
    private val presets = listOf(15, 30, 60, 120, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySetLimitBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        title = "Set Limit — $appName"
        loadAppIcon()
        setupPresetChips()
        setupCustomInput()
        setupSaveButton()
        observeViewModel()

        viewModel.loadExistingLimit(packageName)
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun loadAppIcon() {
        try {
            val icon = packageManager.getApplicationIcon(packageName)
            binding.ivAppIcon.setImageDrawable(icon)
        } catch (e: PackageManager.NameNotFoundException) {
            // Use default icon
        }
        binding.tvAppNameHeader.text = appName
    }

    private fun setupPresetChips() {
        presets.forEach { minutes ->
            val chip = Chip(this).apply {
                text = formatPreset(minutes)
                isCheckable = true
                tag = minutes
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) {
                        selectedMinutes = minutes
                        binding.layoutCustomInput.visibility = View.GONE
                        binding.chipGroupPresets.check(id)
                    }
                }
            }
            binding.chipGroupPresets.addView(chip)
        }

        // Custom chip
        val customChip = Chip(this).apply {
            text = "Custom"
            isCheckable = true
            setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    binding.layoutCustomInput.visibility = View.VISIBLE
                }
            }
        }
        binding.chipGroupPresets.addView(customChip)
    }

    private fun setupCustomInput() {
        binding.layoutCustomInput.visibility = View.GONE
        // NumberPicker for hours
        binding.pickerHours.apply {
            minValue = 0
            maxValue = 23
            wrapSelectorWheel = false
        }
        // NumberPicker for minutes
        binding.pickerMinutes.apply {
            minValue = 0
            maxValue = 59
            wrapSelectorWheel = true
        }
    }

    private fun setupSaveButton() {
        binding.btnSave.setOnClickListener {
            val minutes = getSelectedMinutes()
            if (minutes <= 0) {
                Toast.makeText(this, "Please select a time limit", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            viewModel.saveLimit(packageName, appName, minutes)
        }
    }

    private fun getSelectedMinutes(): Int {
        return if (binding.layoutCustomInput.visibility == View.VISIBLE) {
            val h = binding.pickerHours.value
            val m = binding.pickerMinutes.value
            h * 60 + m
        } else {
            selectedMinutes
        }
    }

    private fun observeViewModel() {
        viewModel.saved.observe(this) { saved ->
            if (saved) {
                Toast.makeText(this, "Limit saved for $appName", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        viewModel.existingLimit.observe(this) { limit ->
            if (limit != null) {
                // Pre-select the matching preset chip, or show custom
                val matchingPreset = presets.find { it == limit.limitMinutes }
                if (matchingPreset != null) {
                    // Find and check the matching chip
                    for (i in 0 until binding.chipGroupPresets.childCount) {
                        val chip = binding.chipGroupPresets.getChildAt(i) as? Chip
                        if (chip?.tag == matchingPreset) {
                            chip.isChecked = true
                            selectedMinutes = matchingPreset
                            break
                        }
                    }
                } else {
                    // Show custom with existing values
                    binding.pickerHours.value   = limit.limitMinutes / 60
                    binding.pickerMinutes.value = limit.limitMinutes % 60
                    binding.layoutCustomInput.visibility = View.VISIBLE
                }
                binding.tvCurrentLimit.text = "Current limit: ${formatPreset(limit.limitMinutes)}"
                binding.tvCurrentLimit.visibility = View.VISIBLE
            }
        }
    }

    private fun formatPreset(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0           -> "${h}h"
            else            -> "${m}m"
        }
    }

    companion object {
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_APP_NAME     = "extra_app_name"
    }
}
