package com.dailyapplock.utils

import java.security.MessageDigest

/**
 * Utility for hashing PIN codes before storage.
 * Uses SHA-256 — never store PIN in plaintext.
 */
object PinHasher {

    private const val SALT = "DailyAppTimeLock_2024_salt"

    /**
     * Returns the SHA-256 hex digest of the salted PIN.
     */
    fun hash(pin: String): String {
        val salted = "$SALT:$pin"
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(salted.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Verifies a candidate PIN against a stored hash.
     */
    fun verify(pin: String, storedHash: String): Boolean {
        return hash(pin) == storedHash
    }
}
