package com.dailyapplock.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.databinding.ActivityPinBinding
import com.dailyapplock.utils.PinHasher

/**
 * PinActivity — handles both PIN setup (MODE_SETUP) and PIN verification (MODE_VERIFY).
 *
 * MODE_SETUP: User sets a 4-digit PIN. Used from Settings.
 * MODE_VERIFY: User must enter their PIN to access the main app or settings.
 */
class PinActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPinBinding
    private val prefs by lazy { (application as DailyAppLockApplication).preferenceManager }

    private var enteredPin = StringBuilder()
    private var firstPin = ""           // Used during setup to confirm PIN
    private var isConfirmingPin = false // Two-step setup flow

    private val mode: String by lazy {
        intent.getStringExtra(EXTRA_MODE) ?: MODE_VERIFY
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupTitle()
        setupNumpad()
    }

    private fun setupTitle() {
        binding.tvPinTitle.text = when (mode) {
            MODE_SETUP -> "Set PIN"
            else       -> "Enter PIN"
        }
        binding.tvPinSubtitle.text = when (mode) {
            MODE_SETUP -> "Choose a 4-digit PIN to protect settings"
            else       -> "Enter your PIN to continue"
        }
    }

    private fun setupNumpad() {
        val buttons = listOf(
            binding.btn0, binding.btn1, binding.btn2, binding.btn3,
            binding.btn4, binding.btn5, binding.btn6, binding.btn7,
            binding.btn8, binding.btn9
        )
        buttons.forEachIndexed { index, button ->
            button.setOnClickListener { appendDigit(index.toString()) }
        }
        binding.btnBackspace.setOnClickListener { deleteDigit() }
        binding.btnClear.setOnClickListener { clearPin() }
    }

    private fun appendDigit(digit: String) {
        if (enteredPin.length >= 4) return
        enteredPin.append(digit)
        updateDots()
        if (enteredPin.length == 4) onPinComplete()
    }

    private fun deleteDigit() {
        if (enteredPin.isNotEmpty()) {
            enteredPin.deleteCharAt(enteredPin.length - 1)
            updateDots()
        }
    }

    private fun clearPin() {
        enteredPin.clear()
        updateDots()
    }

    private fun updateDots() {
        val dots = listOf(binding.dot1, binding.dot2, binding.dot3, binding.dot4)
        dots.forEachIndexed { index, view ->
            view.isSelected = index < enteredPin.length
        }
    }

    private fun onPinComplete() {
        val pin = enteredPin.toString()

        when (mode) {
            MODE_SETUP -> handleSetupPin(pin)
            MODE_VERIFY -> handleVerifyPin(pin)
        }
    }

    private fun handleSetupPin(pin: String) {
        if (!isConfirmingPin) {
            // First entry — ask to confirm
            firstPin = pin
            isConfirmingPin = true
            enteredPin.clear()
            updateDots()
            binding.tvPinTitle.text = "Confirm PIN"
            binding.tvPinSubtitle.text = "Enter your PIN again to confirm"
        } else {
            // Second entry — compare
            if (pin == firstPin) {
                prefs.pinHash = PinHasher.hash(pin)
                prefs.isPinEnabled = true
                Toast.makeText(this, "PIN set successfully", Toast.LENGTH_SHORT).show()
                setResult(RESULT_OK)
                finish()
            } else {
                showError("PINs don't match. Try again.")
                isConfirmingPin = false
                firstPin = ""
                enteredPin.clear()
                updateDots()
                binding.tvPinTitle.text = "Set PIN"
                binding.tvPinSubtitle.text = "Choose a 4-digit PIN"
            }
        }
    }

    private fun handleVerifyPin(pin: String) {
        if (PinHasher.verify(pin, prefs.pinHash)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        } else {
            showError("Incorrect PIN. Try again.")
            clearPin()
        }
    }

    private fun showError(message: String) {
        binding.tvError.text = message
        binding.tvError.visibility = View.VISIBLE
        binding.root.postDelayed({ binding.tvError.visibility = View.GONE }, 2000)
    }

    companion object {
        const val EXTRA_MODE = "extra_mode"
        const val MODE_SETUP  = "setup"
        const val MODE_VERIFY = "verify"
    }
}
