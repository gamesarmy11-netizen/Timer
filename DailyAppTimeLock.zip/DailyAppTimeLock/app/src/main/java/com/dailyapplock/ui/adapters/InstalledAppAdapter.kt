package com.dailyapplock.ui.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.dailyapplock.data.models.InstalledApp
import com.dailyapplock.databinding.ItemInstalledAppBinding
import com.dailyapplock.utils.TimeUtils

/**
 * RecyclerView adapter for the app selection screen.
 * Apps with existing limits show a "configured" badge.
 */
class InstalledAppAdapter(
    private val onAppClick: (InstalledApp) -> Unit
) : ListAdapter<InstalledApp, InstalledAppAdapter.ViewHolder>(DIFF_CALLBACK) {

    inner class ViewHolder(private val binding: ItemInstalledAppBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(app: InstalledApp) {
            binding.ivAppIcon.setImageDrawable(app.icon)
            binding.tvAppName.text = app.appName
            binding.tvPackageName.text = app.packageName

            if (app.hasLimit) {
                binding.tvLimitBadge.visibility = View.VISIBLE
                binding.tvLimitBadge.text = "Limit: ${TimeUtils.formatMinutes(app.limitMinutes)}"
            } else {
                binding.tvLimitBadge.visibility = View.GONE
            }

            binding.root.setOnClickListener { onAppClick(app) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemInstalledAppBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<InstalledApp>() {
            override fun areItemsTheSame(old: InstalledApp, new: InstalledApp) =
                old.packageName == new.packageName
            override fun areContentsTheSame(old: InstalledApp, new: InstalledApp) =
                old == new.copy(icon = old.icon) // icon equality would always fail
        }
    }
}
