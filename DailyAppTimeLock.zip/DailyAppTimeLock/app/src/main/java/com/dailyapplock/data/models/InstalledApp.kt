package com.dailyapplock.data.models

import android.graphics.drawable.Drawable

/**
 * Transient model representing an installed app on the device.
 * Not persisted in the database — populated at runtime from PackageManager.
 */
data class InstalledApp(
    val packageName: String,
    val appName: String,
    val icon: Drawable?,
    val isSystemApp: Boolean = false,
    val isSelected: Boolean = false,    // used in selection UI
    val hasLimit: Boolean = false,      // true if already configured in Room
    val limitMinutes: Int = 0
)
