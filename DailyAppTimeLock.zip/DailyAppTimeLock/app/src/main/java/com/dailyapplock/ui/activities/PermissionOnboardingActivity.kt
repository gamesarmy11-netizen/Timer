package com.dailyapplock.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.databinding.ActivityPermissionOnboardingBinding
import com.dailyapplock.utils.PermissionHelper

/**
 * PermissionOnboardingActivity — step-by-step permission setup.
 *
 * Steps:
 *  1. Usage Access (required)
 *  2. Draw Over Apps / Overlay (required)
 *  3. Accessibility Service (strongly recommended)
 *  4. Battery Optimization (recommended)
 *
 * Users cannot proceed to the main app until required permissions are granted.
 */
class PermissionOnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionOnboardingBinding
    private val prefs by lazy { (application as DailyAppLockApplication).preferenceManager }

    private var currentStep = 0
    private val steps = listOf(
        OnboardingStep(
            title       = "Usage Access",
            description = "Required to track how long each app is used. Without this, Daily App Time Lock cannot monitor or limit your screen time.",
            icon        = "⏱️",
            isRequired  = true
        ),
        OnboardingStep(
            title       = "Draw Over Apps",
            description = "Allows Daily App Time Lock to show the block screen over other apps when a time limit is reached.",
            icon        = "🛡️",
            isRequired  = true
        ),
        OnboardingStep(
            title       = "Accessibility Service",
            description = "Provides an additional layer of blocking. Prevents apps from reopening via notifications, recents, or deep links.",
            icon        = "♿",
            isRequired  = false
        ),
        OnboardingStep(
            title       = "Battery Optimization",
            description = "Prevents Android from killing the monitoring service when the screen is off. Highly recommended.",
            icon        = "🔋",
            isRequired  = false
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateStep()

        binding.btnGrant.setOnClickListener { requestCurrentPermission() }
        binding.btnSkip.setOnClickListener { advanceStep() }
        binding.btnContinue.setOnClickListener { finish_onboarding() }
    }

    override fun onResume() {
        super.onResume()
        // Re-check permissions on resume (user may have granted in Settings)
        updateStepStatus()
    }

    private fun updateStep() {
        if (currentStep >= steps.size) {
            showCompletionScreen()
            return
        }

        val step = steps[currentStep]
        binding.tvStepTitle.text = step.title
        binding.tvStepDescription.text = step.description
        binding.tvStepIcon.text = step.icon
        binding.tvStepCounter.text = "Step ${currentStep + 1} of ${steps.size}"
        binding.btnSkip.visibility = if (step.isRequired) View.GONE else View.VISIBLE
        binding.progressBar.progress = ((currentStep.toFloat() / steps.size) * 100).toInt()

        updateStepStatus()
    }

    private fun updateStepStatus() {
        if (currentStep >= steps.size) return
        val isGranted = isCurrentStepGranted()
        binding.tvGrantedStatus.visibility = if (isGranted) View.VISIBLE else View.GONE
        binding.btnGrant.text = if (isGranted) "✓ Granted — Continue" else "Grant Permission"
        binding.btnGrant.setOnClickListener {
            if (isGranted) advanceStep() else requestCurrentPermission()
        }
    }

    private fun isCurrentStepGranted(): Boolean = when (currentStep) {
        0 -> PermissionHelper.hasUsageAccess(this)
        1 -> PermissionHelper.hasOverlayPermission(this)
        2 -> PermissionHelper.isAccessibilityServiceEnabled(this)
        3 -> PermissionHelper.isBatteryOptimizationIgnored(this)
        else -> false
    }

    private fun requestCurrentPermission() {
        val intent = when (currentStep) {
            0 -> PermissionHelper.getUsageAccessIntent()
            1 -> PermissionHelper.getOverlayIntent(this)
            2 -> PermissionHelper.getAccessibilityIntent()
            3 -> PermissionHelper.getBatteryOptimizationIntent(this)
            else -> return
        }
        startActivity(intent)
    }

    private fun advanceStep() {
        currentStep++
        updateStep()
    }

    private fun showCompletionScreen() {
        binding.layoutStep.visibility = View.GONE
        binding.layoutComplete.visibility = View.VISIBLE
        val allGranted = PermissionHelper.allCriticalPermissionsGranted(this)
        binding.tvCompleteMessage.text = if (allGranted) {
            "✅ All critical permissions granted!\nDaily App Time Lock is ready to protect your screen time."
        } else {
            "⚠️ Some permissions are missing.\nBasic monitoring will work, but blocking may be limited."
        }
    }

    private fun finish_onboarding() {
        // Must have at minimum usage access + overlay to function
        if (!PermissionHelper.hasUsageAccess(this)) {
            binding.tvError.visibility = View.VISIBLE
            binding.tvError.text = "❌ Usage Access is required to continue."
            currentStep = 0
            updateStep()
            return
        }
        if (!PermissionHelper.hasOverlayPermission(this)) {
            binding.tvError.visibility = View.VISIBLE
            binding.tvError.text = "❌ Draw Over Apps permission is required."
            currentStep = 1
            updateStep()
            return
        }

        prefs.isOnboardingComplete = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    data class OnboardingStep(
        val title: String,
        val description: String,
        val icon: String,
        val isRequired: Boolean
    )
}
