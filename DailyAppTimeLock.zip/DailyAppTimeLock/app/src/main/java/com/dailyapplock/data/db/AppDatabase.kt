package com.dailyapplock.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dailyapplock.data.models.AppLimit

/**
 * Room database — single source of truth for all app limit data.
 * Uses a singleton pattern to prevent multiple database instances.
 */
@Database(
    entities = [AppLimit::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appLimitDao(): AppLimitDao

    companion object {
        private const val DATABASE_NAME = "daily_app_lock.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()   // for development; use Migration in production
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
