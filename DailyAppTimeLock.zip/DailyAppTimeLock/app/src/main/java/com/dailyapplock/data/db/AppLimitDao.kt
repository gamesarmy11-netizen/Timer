package com.dailyapplock.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.dailyapplock.data.models.AppLimit
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for the app_limits table.
 * All blocking queries run in coroutines — Room enforces this on the main thread.
 */
@Dao
interface AppLimitDao {

    // ─── Insert / Update ────────────────────────────────────────────────────

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(appLimit: AppLimit)

    @Update
    suspend fun update(appLimit: AppLimit)

    @Transaction
    suspend fun upsert(appLimit: AppLimit) {
        val existing = getByPackageName(appLimit.packageName)
        if (existing == null) insertOrUpdate(appLimit)
        else update(appLimit)
    }

    // ─── Delete ─────────────────────────────────────────────────────────────

    @Delete
    suspend fun delete(appLimit: AppLimit)

    @Query("DELETE FROM app_limits WHERE package_name = :packageName")
    suspend fun deleteByPackage(packageName: String)

    // ─── Queries ────────────────────────────────────────────────────────────

    /** All limits as LiveData — used in Dashboard. */
    @Query("SELECT * FROM app_limits WHERE is_enabled = 1 ORDER BY app_name ASC")
    fun getAllLimitsLive(): LiveData<List<AppLimit>>

    /** All limits as Flow — used in services. */
    @Query("SELECT * FROM app_limits WHERE is_enabled = 1")
    fun getAllLimitsFlow(): Flow<List<AppLimit>>

    /** Synchronous fetch for use inside services without coroutine scope. */
    @Query("SELECT * FROM app_limits WHERE is_enabled = 1")
    fun getAllLimitsSync(): List<AppLimit>

    @Query("SELECT * FROM app_limits WHERE package_name = :packageName LIMIT 1")
    suspend fun getByPackageName(packageName: String): AppLimit?

    @Query("SELECT * FROM app_limits WHERE package_name = :packageName LIMIT 1")
    fun getByPackageSync(packageName: String): AppLimit?

    /** All currently blocked apps. */
    @Query("SELECT * FROM app_limits WHERE is_blocked = 1 AND is_enabled = 1")
    fun getBlockedAppsLive(): LiveData<List<AppLimit>>

    @Query("SELECT * FROM app_limits WHERE is_blocked = 1 AND is_enabled = 1")
    fun getBlockedAppsSync(): List<AppLimit>

    // ─── Usage Updates ───────────────────────────────────────────────────────

    /** Add seconds to an app's used time and mark blocked if limit reached. */
    @Query("""
        UPDATE app_limits 
        SET used_seconds = used_seconds + :seconds,
            is_blocked = CASE WHEN (used_seconds + :seconds) >= (limit_minutes * 60) THEN 1 ELSE is_blocked END
        WHERE package_name = :packageName
    """)
    suspend fun addUsedSeconds(packageName: String, seconds: Long)

    /** Mark app as blocked. */
    @Query("UPDATE app_limits SET is_blocked = 1 WHERE package_name = :packageName")
    suspend fun markBlocked(packageName: String)

    /** Mark warning as sent. */
    @Query("UPDATE app_limits SET warning_sent = 1 WHERE package_name = :packageName")
    suspend fun markWarningSent(packageName: String)

    // ─── Daily Reset ─────────────────────────────────────────────────────────

    /** Reset all usage counters and unblock all apps at midnight. */
    @Query("""
        UPDATE app_limits 
        SET used_seconds = 0, 
            is_blocked = 0, 
            warning_sent = 0,
            last_reset_date = :today
        WHERE is_enabled = 1
    """)
    suspend fun resetAllForDay(today: String)

    /** Reset a single app (manual reset by user). */
    @Query("""
        UPDATE app_limits 
        SET used_seconds = 0, 
            is_blocked = 0,
            warning_sent = 0,
            last_reset_date = :today
        WHERE package_name = :packageName
    """)
    suspend fun resetAppForDay(packageName: String, today: String)

    // ─── Stats ───────────────────────────────────────────────────────────────

    @Query("SELECT COUNT(*) FROM app_limits WHERE is_blocked = 1")
    fun getBlockedCountLive(): LiveData<Int>

    @Query("SELECT COUNT(*) FROM app_limits WHERE is_enabled = 1")
    suspend fun getTotalMonitoredCount(): Int
}
