package com.dailyapplock.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.R
import com.dailyapplock.data.models.AppLimit
import com.dailyapplock.databinding.ActivityMainBinding
import com.dailyapplock.service.AppMonitorService
import com.dailyapplock.service.DailyResetWorker
import com.dailyapplock.ui.adapters.AppLimitAdapter
import com.dailyapplock.ui.viewmodels.DashboardViewModel
import com.dailyapplock.utils.PermissionHelper
import com.google.android.material.snackbar.Snackbar

/**
 * MainActivity — the main dashboard.
 *
 * Shows:
 *  - Status summary (monitoring status, blocked count, reset countdown)
 *  - List of all monitored apps with their usage/remaining time
 *  - FAB to add new app limits
 *  - Permission warning banner if critical permissions are missing
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: DashboardViewModel by viewModels()
    private lateinit var adapter: AppLimitAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        setupRecyclerView()
        setupFab()
        observeViewModel()

        // Start monitoring service
        AppMonitorService.start(this)

        // Schedule midnight reset
        DailyResetWorker.scheduleMidnightReset(this)
    }

    override fun onResume() {
        super.onResume()
        checkPermissionWarning()
    }

    // ─── Setup ───────────────────────────────────────────────────────────────

    private fun setupRecyclerView() {
        adapter = AppLimitAdapter(
            onEditClick  = { limit -> openSetLimit(limit) },
            onDeleteClick = { limit -> confirmDelete(limit) },
            onResetClick  = { limit -> viewModel.resetAppManually(limit) }
        )
        binding.recyclerApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerApps.adapter = adapter
    }

    private fun setupFab() {
        binding.fabAddApp.setOnClickListener {
            startActivity(Intent(this, AppSelectionActivity::class.java))
        }
    }

    // ─── Observation ─────────────────────────────────────────────────────────

    private fun observeViewModel() {
        viewModel.allLimits.observe(this) { limits ->
            adapter.submitList(limits)
            binding.layoutEmptyState.visibility = if (limits.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerApps.visibility = if (limits.isEmpty()) View.GONE else View.VISIBLE
        }

        viewModel.blockedCount.observe(this) { count ->
            binding.tvBlockedCount.text = count.toString()
            binding.cardBlockedCount.visibility = if (count > 0) View.VISIBLE else View.GONE
        }

        viewModel.countdownFormatted.observe(this) { countdown ->
            binding.tvResetCountdown.text = countdown
        }

        viewModel.message.observe(this) { msg ->
            if (msg != null) {
                Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
                viewModel.clearMessage()
            }
        }
    }

    // ─── Permission warning ───────────────────────────────────────────────────

    private fun checkPermissionWarning() {
        val hasUsage   = PermissionHelper.hasUsageAccess(this)
        val hasOverlay = PermissionHelper.hasOverlayPermission(this)
        val hasA11y    = PermissionHelper.isAccessibilityServiceEnabled(this)

        if (!hasUsage || !hasOverlay) {
            binding.bannerPermission.visibility = View.VISIBLE
            binding.tvPermissionWarning.text = when {
                !hasUsage   -> "⚠️ Usage Access missing — monitoring disabled"
                !hasOverlay -> "⚠️ Overlay permission missing — blocking disabled"
                else        -> "⚠️ Some permissions missing"
            }
            binding.bannerPermission.setOnClickListener {
                startActivity(Intent(this, PermissionOnboardingActivity::class.java))
            }
        } else {
            binding.bannerPermission.visibility = View.GONE
        }

        if (!hasA11y) {
            binding.tvA11yWarning.visibility = View.VISIBLE
        } else {
            binding.tvA11yWarning.visibility = View.GONE
        }
    }

    // ─── Navigation ──────────────────────────────────────────────────────────

    private fun openSetLimit(limit: AppLimit) {
        val intent = Intent(this, SetLimitActivity::class.java).apply {
            putExtra(SetLimitActivity.EXTRA_PACKAGE_NAME, limit.packageName)
            putExtra(SetLimitActivity.EXTRA_APP_NAME, limit.appName)
        }
        startActivity(intent)
    }

    private fun confirmDelete(limit: AppLimit) {
        AlertDialog.Builder(this)
            .setTitle("Remove Limit")
            .setMessage("Stop monitoring ${limit.appName}?")
            .setPositiveButton("Remove") { _, _ -> viewModel.deleteAppLimit(limit) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ─── Menu ────────────────────────────────────────────────────────────────

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_settings -> {
            showSettingsDialog()
            true
        }
        R.id.action_reset_all -> {
            confirmResetAll()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    private fun showSettingsDialog() {
        val prefs = (application as DailyAppLockApplication).preferenceManager
        val options = arrayOf(
            if (prefs.isPinEnabled) "Change PIN" else "Set PIN",
            if (prefs.isPinEnabled) "Remove PIN" else "",
            "Permissions"
        ).filter { it.isNotEmpty() }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setItems(options) { _, which ->
                when (options[which]) {
                    "Set PIN", "Change PIN" -> {
                        val intent = Intent(this, PinActivity::class.java)
                            .putExtra(PinActivity.EXTRA_MODE, PinActivity.MODE_SETUP)
                        startActivity(intent)
                    }
                    "Remove PIN" -> {
                        prefs.isPinEnabled = false
                        prefs.pinHash = ""
                        Toast.makeText(this, "PIN removed", Toast.LENGTH_SHORT).show()
                    }
                    "Permissions" -> {
                        startActivity(Intent(this, PermissionOnboardingActivity::class.java))
                    }
                }
            }
            .show()
    }

    private fun confirmResetAll() {
        AlertDialog.Builder(this)
            .setTitle("Reset All")
            .setMessage("Reset usage for all apps? This will unblock all apps for today.")
            .setPositiveButton("Reset All") { _, _ ->
                viewModel.resetAppManually(
                    com.dailyapplock.data.models.AppLimit("__all__", "All Apps", 0)
                )
                // Actually reset all via repository directly
                val app = application as DailyAppLockApplication
                androidx.lifecycle.lifecycleScope.launch {
                    app.repository.resetAllForToday()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
