package com.dailyapplock.data.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room entity representing a single app's time-limit configuration and usage tracking.
 *
 * @param packageName  Unique package name — used as primary key
 * @param appName      Human-readable app label
 * @param limitMinutes Daily limit in minutes (e.g. 60 = 1 hour)
 * @param usedMinutes  Minutes used so far today (accumulated across sessions)
 * @param isBlocked    True when daily limit has been exhausted
 * @param isEnabled    False if user has temporarily disabled monitoring for this app
 * @param lastResetDate Date string (yyyy-MM-dd) of last midnight reset
 * @param iconBase64   Optional base64-encoded app icon (stored for quick display)
 */
@Entity(tableName = "app_limits")
data class AppLimit(
    @PrimaryKey
    @ColumnInfo(name = "package_name")
    val packageName: String,

    @ColumnInfo(name = "app_name")
    val appName: String,

    @ColumnInfo(name = "limit_minutes")
    val limitMinutes: Int,

    @ColumnInfo(name = "used_seconds")
    val usedSeconds: Long = 0L,           // stored in seconds for precision

    @ColumnInfo(name = "is_blocked")
    val isBlocked: Boolean = false,

    @ColumnInfo(name = "is_enabled")
    val isEnabled: Boolean = true,

    @ColumnInfo(name = "last_reset_date")
    val lastResetDate: String = "",        // format: "yyyy-MM-dd"

    @ColumnInfo(name = "warning_sent")
    val warningSent: Boolean = false       // track if 5-min warning was sent today
) {
    /** Convenience: limit expressed in seconds */
    val limitSeconds: Long get() = limitMinutes * 60L

    /** Remaining seconds until limit is hit */
    val remainingSeconds: Long get() = maxOf(0L, limitSeconds - usedSeconds)

    /** Minutes used (rounded down) */
    val usedMinutes: Int get() = (usedSeconds / 60).toInt()

    /** Remaining minutes (rounded down) */
    val remainingMinutes: Int get() = (remainingSeconds / 60).toInt()

    /** Usage percentage 0..100 */
    val usagePercent: Float get() = if (limitSeconds == 0L) 100f
        else (usedSeconds.toFloat() / limitSeconds.toFloat()).coerceIn(0f, 1f) * 100f
}
