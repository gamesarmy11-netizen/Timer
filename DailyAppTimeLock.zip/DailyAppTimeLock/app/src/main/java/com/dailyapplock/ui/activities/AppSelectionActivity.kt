package com.dailyapplock.ui.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.dailyapplock.databinding.ActivityAppSelectionBinding
import com.dailyapplock.ui.adapters.InstalledAppAdapter
import com.dailyapplock.ui.viewmodels.AppSelectionViewModel

/**
 * AppSelectionActivity — browse and select installed apps to set time limits on.
 * Tapping an app navigates to SetLimitActivity.
 */
class AppSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppSelectionBinding
    private val viewModel: AppSelectionViewModel by viewModels()
    private lateinit var adapter: InstalledAppAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Select App"

        setupRecyclerView()
        setupSearch()
        observeViewModel()

        viewModel.loadInstalledApps()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun setupRecyclerView() {
        adapter = InstalledAppAdapter { app ->
            val intent = Intent(this, SetLimitActivity::class.java).apply {
                putExtra(SetLimitActivity.EXTRA_PACKAGE_NAME, app.packageName)
                putExtra(SetLimitActivity.EXTRA_APP_NAME, app.appName)
            }
            startActivity(intent)
        }
        binding.recyclerApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerApps.adapter = adapter
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                viewModel.search(newText ?: "")
                return true
            }
        })
    }

    private fun observeViewModel() {
        viewModel.isLoading.observe(this) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        }
        viewModel.filteredApps.observe(this) { apps ->
            adapter.submitList(apps)
        }
    }
}
