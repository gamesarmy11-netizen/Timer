package com.dailyapplock.ui.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.databinding.ActivityLockScreenBinding
import com.dailyapplock.utils.TimeUtils

/**
 * LockScreenActivity — the full-screen overlay shown when an app's daily limit is hit.
 *
 * Design goals:
 *  - Cannot be dismissed by Back button
 *  - Shows which app is blocked and why
 *  - Shows time until midnight reset (countdown)
 *  - Can only be exited by pressing "Go to Home"
 *  - Remains on top using TYPE_APPLICATION_OVERLAY if API permits
 */
class LockScreenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLockScreenBinding
    private val prefs by lazy { (application as DailyAppLockApplication).preferenceManager }

    private val blockedPackage by lazy { intent.getStringExtra(EXTRA_PACKAGE) ?: "" }
    private val blockedAppName by lazy { intent.getStringExtra(EXTRA_APP_NAME) ?: "App" }

    private val handler = Handler(Looper.getMainLooper())
    private val countdownRunnable = object : Runnable {
        override fun run() {
            val millis = TimeUtils.millisUntilMidnight()
            binding.tvCountdown.text = "Resets in ${TimeUtils.formatCountdown(millis)}"
            handler.postDelayed(this, 1_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen on and show above lock screen
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        binding = ActivityLockScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadBlockedAppInfo()
        setupButtons()
        handler.post(countdownRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(countdownRunnable)
    }

    // ─── Block system navigation buttons ────────────────────────────────────

    /** Intercept Back button — prevent dismissal */
    override fun onBackPressed() {
        // Do nothing — lock screen cannot be dismissed via Back
        goHome()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_HOME,
            KeyEvent.KEYCODE_APP_SWITCH -> {
                goHome()
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    // ─── UI ─────────────────────────────────────────────────────────────────

    private fun loadBlockedAppInfo() {
        binding.tvBlockedAppName.text = blockedAppName
        binding.tvMessage.text = "You've reached your daily limit for $blockedAppName"

        // Load app icon
        try {
            val icon = packageManager.getApplicationIcon(blockedPackage)
            binding.ivBlockedAppIcon.setImageDrawable(icon)
        } catch (e: Exception) {
            // Default icon
        }
    }

    private fun setupButtons() {
        binding.btnGoHome.setOnClickListener { goHome() }

        // Optional: open Daily App Time Lock dashboard
        binding.btnOpenDashboard.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(intent)
            // Don't finish — lock screen should remain in back stack for this blocked app
        }
    }

    private fun goHome() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
    }

    // ─── Static factory ──────────────────────────────────────────────────────

    companion object {
        const val EXTRA_PACKAGE  = "extra_blocked_package"
        const val EXTRA_APP_NAME = "extra_blocked_app_name"

        fun newIntent(context: Context, packageName: String, appName: String): Intent =
            Intent(context, LockScreenActivity::class.java).apply {
                putExtra(EXTRA_PACKAGE, packageName)
                putExtra(EXTRA_APP_NAME, appName)
            }
    }
}
