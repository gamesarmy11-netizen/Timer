package com.dailyapplock.ui.activities

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.R

/**
 * SplashActivity — brief branded splash screen.
 * Routes to: PermissionOnboardingActivity (first launch) → PinActivity (if set) → MainActivity
 */
@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val prefs = (application as DailyAppLockApplication).preferenceManager

        Handler(Looper.getMainLooper()).postDelayed({
            val destination = when {
                !prefs.isOnboardingComplete -> PermissionOnboardingActivity::class.java
                prefs.isPinEnabled          -> PinActivity::class.java
                else                        -> MainActivity::class.java
            }
            startActivity(Intent(this, destination))
            finish()
        }, SPLASH_DELAY_MS)
    }

    companion object {
        private const val SPLASH_DELAY_MS = 1500L
    }
}
