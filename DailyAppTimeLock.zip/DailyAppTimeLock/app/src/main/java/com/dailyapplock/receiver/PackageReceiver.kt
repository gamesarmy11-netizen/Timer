package com.dailyapplock.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.dailyapplock.DailyAppLockApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * PackageReceiver — listens for app uninstall/replace events.
 * Cleans up the database if a monitored app is removed.
 */
class PackageReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val packageName = intent.data?.schemeSpecificPart ?: return
        Log.d(TAG, "Package event: ${intent.action} — $packageName")

        if (intent.action == Intent.ACTION_PACKAGE_REMOVED &&
            !intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) {
            // App truly removed (not just updating) — delete its limit
            val app = context.applicationContext as DailyAppLockApplication
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                app.repository.deleteAppLimit(packageName)
                Log.d(TAG, "Removed limit for uninstalled app: $packageName")
            }
        }
    }

    companion object {
        private const val TAG = "PackageReceiver"
    }
}
