package com.dailyapplock.ui.adapters

import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.dailyapplock.data.models.AppLimit
import com.dailyapplock.databinding.ItemAppLimitBinding
import com.dailyapplock.utils.TimeUtils

/**
 * RecyclerView adapter for the dashboard's monitored-apps list.
 * Uses DiffUtil for efficient updates.
 */
class AppLimitAdapter(
    private val onEditClick:   (AppLimit) -> Unit,
    private val onDeleteClick: (AppLimit) -> Unit,
    private val onResetClick:  (AppLimit) -> Unit
) : ListAdapter<AppLimit, AppLimitAdapter.ViewHolder>(DIFF_CALLBACK) {

    inner class ViewHolder(private val binding: ItemAppLimitBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(limit: AppLimit) {
            // App icon
            try {
                val icon = binding.root.context.packageManager
                    .getApplicationIcon(limit.packageName)
                binding.ivAppIcon.setImageDrawable(icon)
            } catch (e: PackageManager.NameNotFoundException) {
                binding.ivAppIcon.setImageResource(android.R.drawable.sym_def_app_icon)
            }

            binding.tvAppName.text = limit.appName

            // Usage progress bar
            binding.progressUsage.progress = limit.usagePercent.toInt()
            binding.progressUsage.max = 100

            // Time strings
            binding.tvUsed.text = "Used: ${TimeUtils.formatSeconds(limit.usedSeconds)}"
            binding.tvRemaining.text = if (limit.isBlocked) {
                "Blocked until midnight"
            } else {
                "Remaining: ${TimeUtils.formatSeconds(limit.remainingSeconds)}"
            }
            binding.tvLimit.text = "Limit: ${TimeUtils.formatMinutes(limit.limitMinutes)}"

            // Blocked state styling
            if (limit.isBlocked) {
                binding.cardRoot.alpha = 0.7f
                binding.tvBlockedBadge.visibility = View.VISIBLE
                binding.progressUsage.progress = 100
                binding.tvRemaining.setTextColor(binding.root.context.getColor(android.R.color.holo_red_light))
            } else {
                binding.cardRoot.alpha = 1f
                binding.tvBlockedBadge.visibility = View.GONE
                binding.tvRemaining.setTextColor(binding.root.context.getColor(android.R.color.white))
            }

            // Button listeners
            binding.btnEdit.setOnClickListener   { onEditClick(limit) }
            binding.btnDelete.setOnClickListener { onDeleteClick(limit) }
            binding.btnReset.setOnClickListener  { onResetClick(limit) }
            binding.btnReset.visibility = if (limit.isBlocked || limit.usedSeconds > 0) View.VISIBLE else View.GONE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAppLimitBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<AppLimit>() {
            override fun areItemsTheSame(old: AppLimit, new: AppLimit) =
                old.packageName == new.packageName

            override fun areContentsTheSame(old: AppLimit, new: AppLimit) = old == new
        }
    }
}
