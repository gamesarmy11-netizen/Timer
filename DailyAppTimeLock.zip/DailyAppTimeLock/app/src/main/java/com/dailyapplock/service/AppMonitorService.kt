package com.dailyapplock.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.dailyapplock.DailyAppLockApplication
import com.dailyapplock.DailyAppLockApplication.Companion.CHANNEL_MONITOR
import com.dailyapplock.DailyAppLockApplication.Companion.CHANNEL_WARNING
import com.dailyapplock.DailyAppLockApplication.Companion.NOTIF_MONITOR
import com.dailyapplock.DailyAppLockApplication.Companion.NOTIF_WARNING
import com.dailyapplock.R
import com.dailyapplock.data.models.AppLimit
import com.dailyapplock.data.repository.AppLimitRepository
import com.dailyapplock.ui.activities.LockScreenActivity
import com.dailyapplock.ui.activities.MainActivity
import com.dailyapplock.utils.PermissionHelper
import com.dailyapplock.utils.PreferenceManager
import com.dailyapplock.utils.TimeUtils
import kotlinx.coroutines.*

/**
 * AppMonitorService — the heart of the blocking system.
 *
 * This foreground service runs continuously and:
 *  1. Polls the foreground app every 400ms using UsageStatsManager
 *  2. Tracks active usage time for each monitored app
 *  3. Blocks apps when their daily limit is reached
 *  4. Sends a warning notification 5 minutes before the limit
 *  5. Shows the LockScreenActivity overlay on block
 *
 * Architecture note:
 *  - Runs on a Handler (main looper) for the poll loop
 *  - DB writes happen via coroutines on Dispatchers.IO
 *  - Relies on BlockAccessibilityService for an additional blocking layer
 */
class AppMonitorService : Service() {

    private lateinit var repository: AppLimitRepository
    private lateinit var prefs: PreferenceManager
    private lateinit var wakeLock: PowerManager.WakeLock
    private lateinit var usageStatsManager: UsageStatsManager

    private val handler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Current foreground package (updated every poll cycle)
    private var currentForegroundPkg: String = ""

    // Per-session tracking — package → session start time (System.currentTimeMillis)
    private val sessionStartTime = mutableMapOf<String, Long>()

    // In-memory cache of limit configs (refreshed from DB every 30s)
    private var limitCache: Map<String, AppLimit> = emptyMap()
    private var lastCacheRefresh = 0L

    // ─── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        repository = (application as DailyAppLockApplication).repository
        prefs      = (application as DailyAppLockApplication).preferenceManager
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        // Acquire partial wake lock so service isn't killed when screen is off
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "DailyAppTimeLock::MonitorWakeLock"
        ).apply { acquire(10 * 60 * 60 * 1000L) } // max 10 hours safety timeout

        startForeground(NOTIF_MONITOR, buildForegroundNotification())
        refreshLimitCache()
        handler.post(pollRunnable)

        Log.d(TAG, "AppMonitorService started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Restart after kill
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(pollRunnable)
        serviceScope.cancel()
        if (wakeLock.isHeld) wakeLock.release()
        Log.d(TAG, "AppMonitorService destroyed — scheduling restart")
        // Restart via broadcast
        sendBroadcast(Intent("$packageName.RESTART_MONITOR_SERVICE"))
    }

    // ─── Poll Loop ──────────────────────────────────────────────────────────

    /**
     * Core poll runnable — runs every POLL_INTERVAL_MS.
     * Detects the current foreground app and applies usage tracking + blocking.
     */
    private val pollRunnable = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (e: Exception) {
                Log.e(TAG, "Poll error: ${e.message}")
            }
            handler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    private fun tick() {
        // Skip if usage access has been revoked (tamper detection)
        if (!PermissionHelper.hasUsageAccess(this)) {
            handleTamper()
            return
        }

        // Refresh cache periodically
        val now = System.currentTimeMillis()
        if (now - lastCacheRefresh > CACHE_REFRESH_INTERVAL_MS) {
            refreshLimitCache()
        }

        val foregroundPkg = getForegroundPackage() ?: return

        // Package changed — flush the previous session
        if (foregroundPkg != currentForegroundPkg) {
            flushSession(currentForegroundPkg, now)
            currentForegroundPkg = foregroundPkg
            // Only start a new session for monitored apps
            if (limitCache.containsKey(foregroundPkg)) {
                sessionStartTime[foregroundPkg] = now
            }
        }

        // Check if currently monitored foreground app should be blocked
        val limit = limitCache[foregroundPkg] ?: return

        if (limit.isBlocked) {
            // Already blocked — trigger lock screen
            triggerLockScreen(foregroundPkg, limit.appName)
            return
        }

        // Calculate real-time used seconds (DB value + current session)
        val sessionStart = sessionStartTime[foregroundPkg] ?: return
        val liveUsedSeconds = limit.usedSeconds + ((now - sessionStart) / 1000L)

        // Warn at 5 minutes before limit
        val remainingSeconds = limit.limitSeconds - liveUsedSeconds
        val warningThresholdSec = prefs.warningThresholdMinutes * 60L
        if (!limit.warningSent && remainingSeconds in 1..warningThresholdSec) {
            sendWarningNotification(limit.appName, remainingSeconds)
            serviceScope.launch { repository.markWarningSent(foregroundPkg) }
            // Refresh cache to pick up warningSent flag
            serviceScope.launch { refreshLimitCache() }
        }

        // Block when limit reached
        if (liveUsedSeconds >= limit.limitSeconds) {
            blockApp(limit, now)
        }
    }

    // ─── Foreground detection ────────────────────────────────────────────────

    /**
     * Returns the current foreground app package using UsageStatsManager.
     * Queries a 3-second window to reduce stale-data risk on fast switching.
     */
    private fun getForegroundPackage(): String? {
        val now = System.currentTimeMillis()
        val stats = usageStatsManager.queryUsageStats(
            UsageStatsManager.INTERVAL_BEST,
            now - 3_000,
            now
        ) ?: return null

        return stats.maxByOrNull { it.lastTimeUsed }
            ?.takeIf { it.lastTimeUsed > (now - 3_000) }
            ?.packageName
    }

    // ─── Session management ──────────────────────────────────────────────────

    /**
     * Flush accumulated session time to the database for a package.
     * Called whenever the foreground app changes.
     */
    private fun flushSession(packageName: String, now: Long) {
        val start = sessionStartTime.remove(packageName) ?: return
        val elapsed = (now - start) / 1000L
        if (elapsed <= 0) return

        val limit = limitCache[packageName] ?: return
        if (limit.isBlocked) return   // don't accumulate after block

        serviceScope.launch {
            repository.addUsedSeconds(packageName, elapsed)
            // Check if this flush pushed it over the limit
            val updated = repository.getAppLimit(packageName)
            if (updated != null && !updated.isBlocked && updated.usedSeconds >= updated.limitSeconds) {
                repository.markBlocked(packageName)
                refreshLimitCache()
            }
        }
        Log.d(TAG, "Flushed $elapsed seconds for $packageName")
    }

    // ─── Blocking ────────────────────────────────────────────────────────────

    private fun blockApp(limit: AppLimit, now: Long) {
        // Flush current session first
        val start = sessionStartTime.remove(limit.packageName)
        if (start != null) {
            val elapsed = (now - start) / 1000L
            serviceScope.launch { repository.addUsedSeconds(limit.packageName, elapsed) }
        }

        serviceScope.launch {
            repository.markBlocked(limit.packageName)
            refreshLimitCache()
        }

        Log.d(TAG, "BLOCKING ${limit.packageName} — daily limit reached!")
        triggerLockScreen(limit.packageName, limit.appName)
    }

    /**
     * Launches the full-screen lock overlay.
     * Uses FLAG_ACTIVITY_NEW_TASK because we're starting from a Service.
     */
    private fun triggerLockScreen(packageName: String, appName: String) {
        val intent = LockScreenActivity.newIntent(this, packageName, appName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                      Intent.FLAG_ACTIVITY_CLEAR_TOP or
                      Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(intent)
    }

    // ─── Cache ───────────────────────────────────────────────────────────────

    private fun refreshLimitCache() {
        val limits = repository.getAllLimitsSync()
        limitCache = limits.associateBy { it.packageName }
        lastCacheRefresh = System.currentTimeMillis()
    }

    // ─── Tamper detection ────────────────────────────────────────────────────

    private fun handleTamper() {
        Log.w(TAG, "TAMPER DETECTED — Usage Access permission removed!")
        // Notify user
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val notification = NotificationCompat.Builder(this, DailyAppLockApplication.CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_warning)
            .setContentTitle("⚠️ Permission Removed!")
            .setContentText("Usage Access was revoked. Blocking is inactive. Tap to fix.")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0,
                    Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
        notificationManager.notify(NOTIF_WARNING, notification)
    }

    // ─── Notifications ───────────────────────────────────────────────────────

    private fun buildForegroundNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_MONITOR)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentTitle("Daily App Time Lock")
            .setContentText("Monitoring active — protecting your screen time")
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun sendWarningNotification(appName: String, remainingSeconds: Long) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val remaining = TimeUtils.formatSeconds(remainingSeconds)
        val notification = NotificationCompat.Builder(this, CHANNEL_WARNING)
            .setSmallIcon(R.drawable.ic_warning)
            .setContentTitle("⏱️ Time limit almost reached")
            .setContentText("$appName has $remaining remaining today")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        notificationManager.notify(NOTIF_WARNING + appName.hashCode(), notification)
    }

    // ─── Static helpers ──────────────────────────────────────────────────────

    companion object {
        private const val TAG = "AppMonitorService"
        private const val POLL_INTERVAL_MS        = 400L     // check every 400ms
        private const val CACHE_REFRESH_INTERVAL_MS = 30_000L // refresh DB cache every 30s

        fun start(context: Context) {
            val intent = Intent(context, AppMonitorService::class.java)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AppMonitorService::class.java))
        }
    }
}
