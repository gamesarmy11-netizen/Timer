package com.dailyapplock.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.dailyapplock.service.AppMonitorService
import com.dailyapplock.service.DailyResetWorker
import com.dailyapplock.utils.PreferenceManager

/**
 * BootReceiver — restarts the monitoring service after device reboot.
 * Also re-schedules the midnight WorkManager task.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        Log.d(TAG, "BootReceiver triggered: $action")

        val prefs = PreferenceManager(context)

        // Only restart if monitoring was active before reboot
        if (!prefs.isMonitoringActive) {
            Log.d(TAG, "Monitoring disabled — skipping restart")
            return
        }

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.huawei.systemmanager.optimize.process.ProtectActivity" -> {
                Log.d(TAG, "Restarting AppMonitorService after boot")
                AppMonitorService.start(context)
                DailyResetWorker.scheduleMidnightReset(context)
            }
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}
