package com.dailyapplock

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.dailyapplock.data.db.AppDatabase
import com.dailyapplock.data.repository.AppLimitRepository
import com.dailyapplock.utils.PreferenceManager

/**
 * Application class — initialises global singletons and notification channels.
 */
class DailyAppLockApplication : Application() {

    // Lazy-initialised singletons accessible app-wide
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: AppLimitRepository by lazy { AppLimitRepository(database) }
    val preferenceManager: PreferenceManager by lazy { PreferenceManager(this) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    /**
     * Creates all notification channels required by the app.
     * Channels are only created on Android O (API 26) and above.
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            // Foreground service channel (persistent, low priority)
            val monitorChannel = NotificationChannel(
                CHANNEL_MONITOR,
                "App Monitor Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Daily App Time Lock running in background"
                setShowBadge(false)
            }

            // Alert channel for limit reached notifications
            val alertChannel = NotificationChannel(
                CHANNEL_ALERT,
                "Time Limit Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when app time limit is reached"
                enableVibration(true)
                enableLights(true)
            }

            // Warning channel (5 minutes before limit)
            val warningChannel = NotificationChannel(
                CHANNEL_WARNING,
                "Time Limit Warnings",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Warns when approaching time limit"
            }

            notificationManager.createNotificationChannels(
                listOf(monitorChannel, alertChannel, warningChannel)
            )
        }
    }

    companion object {
        const val CHANNEL_MONITOR = "channel_monitor"
        const val CHANNEL_ALERT   = "channel_alert"
        const val CHANNEL_WARNING = "channel_warning"

        // Notification IDs
        const val NOTIF_MONITOR  = 1001
        const val NOTIF_ALERT    = 1002
        const val NOTIF_WARNING  = 1003
    }
}
